Code Documentation
==================

For code documentation, we now use `Doxygen <https://www.doxygen.nl/index.html>`_!

At the moment, the documentation files are not provided and have to be built locally:

1. Install doxygen :code:`sudo apt install doxygen`
2. Run doxygen in the root folder :code:`agilicious/` by simply issuing the :code:`doxygen` command.
3. Open the documentation in your favourite browser by clicking :code:`agilicious/docs/html/index.html`!
