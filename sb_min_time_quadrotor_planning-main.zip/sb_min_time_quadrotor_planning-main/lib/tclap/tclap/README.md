This is a simple templatized C++ library for parsing command line arguments. The library provides a simple, flexible object-oriented interface to the command line that automates argument parsing, USAGE creation and type casting.
https://sourceforge.net/projects/tclap/
